namespace YG.Insides
{
    public partial class OptionalPlatform
    {
        public void HappyTime()
        {
            YG2.Message("Happy Time");
            YG2.iPlatform.HappyTime();
        }
    }
}