using YG.Insides;

namespace YG
{
    public partial class InfoYG
    {
        public CommonOptions common = new CommonOptions();
    }
}

namespace YG.Insides
{
    [System.Serializable]
    public partial class CommonOptions
    {
        /// [ApplySettings] [SelectPlatform] [DeletePlatform]
    }
}
